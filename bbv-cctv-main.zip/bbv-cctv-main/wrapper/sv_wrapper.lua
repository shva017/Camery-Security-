Wrapper = {
    resname = GetCurrentResourceName(),
    ServerCallbacks = {}
}
