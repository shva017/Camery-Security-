Discord : https://discord.com/ywBqCcw3Rz

![CCTV_MAIN](https://github.com/BuddyNotFound/bbv-cctv/assets/74051918/aa3ee704-2371-4821-b9b9-f3abc14d12e0)

CCTV Script that allows police officers or any job set from the config to access a tablet where you can check the cameras. You can add as many cameras as you want and place them anywhere. You can use an item or a command to access the system. The script works with both QB and ESX frameworks or can be run as standalone.

Props get created for the cameras - 
![image](https://github.com/BuddyNotFound/bbv-cctv/assets/74051918/ff11bfa7-a899-4c7f-bcd2-8ddf1a52c16b)


**Features :**

* Support for QB/ESX & Standalone.
* Props Get Created for the cameras. - [video](https://streamable.com/cwbqcy)
* Job Restriction.
* You can use an item/command or  a key to open it.
* Easy to add more cameras.

> Preview : 

https://streamable.com/m0ok9x
